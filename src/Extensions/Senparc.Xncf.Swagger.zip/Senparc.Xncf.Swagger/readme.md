## Senparc.Xncf.Swagger 项目说明

MVC模式设置文档生成，需要：
1.标注接口访问方法类型，如：[HttpGet]
2.标注接口所属版本，如：[ApiVersion("1")]
3.设置接口方法路由，如：[Route("GetTest")]

Page模式设置文档生成：
暂不支持

如需设置注释的支持，需要在项目属性-->生成面板的输出模块选中“XML文档文件”
